"""Local numerical exploration; run only outside model timing windows."""
import json

import torch
import triton
import triton.language as tl


@triton.jit
def square_kernel(X, Y, SIZE: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    x = tl.load(X + i, i < SIZE, other=0).to(tl.float32)
    tl.store(Y + i, x * x, i < SIZE)


@triton.jit
def scale_kernel(X, S, Y, SIZE: tl.constexpr, WIDTH: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    x = tl.load(X + i, i < SIZE, other=0).to(tl.float32)
    s = tl.load(S + i // WIDTH, i < SIZE, other=0)
    tl.store(Y + i, x * s, i < SIZE)


@triton.jit
def weighted_kernel(X, P, Y, N: tl.constexpr, D: tl.constexpr,
                    PS: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    token, col = i // D, i % D
    acc = tl.full((BLOCK,), 0, tl.float32)
    for k in range(4):
        x = tl.load(X + token * 4 * D + k * D + col, token < N, other=0).to(tl.float32)
        p = tl.load(P + token * PS + k, token < N, other=0).to(tl.bfloat16).to(tl.float32)
        acc = tl.fma(x, p, acc)
    tl.store(Y + i, acc, token < N)


@triton.jit
def epilogue_kernel(M, B, P, Y, N: tl.constexpr, D: tl.constexpr,
                    PS: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    token, row, col = i // (4 * D), (i // D) % 4, i % D
    m = tl.load(M + i, token < N, other=0).to(tl.float32)
    b = tl.load(B + token * D + col, token < N, other=0).to(tl.float32)
    p = tl.load(P + token * PS + row, token < N, other=0).to(tl.bfloat16).to(tl.float32)
    scaled = (p * b).to(tl.bfloat16).to(tl.float32)
    tl.store(Y + i, m + scaled, token < N)


@triton.jit
def merge_kernel(X, B, P, M, Y, N: tl.constexpr, D: tl.constexpr,
                 PS: tl.constexpr, MS: tl.constexpr, BLOCK: tl.constexpr):
    i = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    token, row, col = i // (4 * D), (i // D) % 4, i % D
    acc = tl.full((BLOCK,), 0, tl.float32)
    for k in range(4):
        x = tl.load(X + token * 4 * D + k * D + col, token < N, other=0).to(tl.float32)
        m = tl.load(M + token * MS + row * 4 + k, token < N, other=0).to(tl.bfloat16).to(tl.float32)
        acc = tl.fma(x, m, acc)
    mixed = acc.to(tl.bfloat16).to(tl.float32)
    b = tl.load(B + token * D + col, token < N, other=0).to(tl.float32)
    p = tl.load(P + token * PS + row, token < N, other=0).to(tl.bfloat16).to(tl.float32)
    scaled = (p * b).to(tl.bfloat16).to(tl.float32)
    tl.store(Y + i, mixed + scaled, token < N)


def norm(x):
    n, streams, d = x.shape
    squared = torch.empty((n, streams * d), device=x.device, dtype=torch.float32)
    square_kernel[(triton.cdiv(x.numel(), 1024),)](x, squared, x.numel(), 1024, enable_fp_fusion=False)
    scale = torch.rsqrt(squared.mean(-1, keepdim=True) + 1e-6)
    y = torch.empty_like(squared)
    scale_kernel[(triton.cdiv(x.numel(), 1024),)](x, scale, y, x.numel(), streams * d, 1024, enable_fp_fusion=False)
    return y


def pre(x, p):
    n, _, d = x.shape
    y = torch.empty((n, d), device=x.device, dtype=x.dtype)
    weighted_kernel[(triton.cdiv(n * d, 1024),)](x, p, y, n, d, p.stride(0), 1024, enable_fp_fusion=False)
    return y


def merge(x, b, p, m, full=True):
    n, _, d = x.shape
    y = torch.empty_like(x)
    grid = (triton.cdiv(x.numel(), 1024),)
    if full:
        merge_kernel[grid](x, b, p, m, y, n, d, p.stride(0), m.stride(0), 1024, enable_fp_fusion=False)
    else:
        mixed = m.to(x.dtype) @ x
        epilogue_kernel[grid](mixed, b, p, y, n, d, p.stride(0), 1024, enable_fp_fusion=False)
    return y


def check(name, a, b):
    return {"op": name, "equal": torch.equal(a.view(torch.uint8), b.view(torch.uint8)),
            "unequal": int((a != b).sum()), "max_abs": float((a.float() - b.float()).abs().max())}


if __name__ == "__main__":
    torch.manual_seed(17)
    with torch.inference_mode():
        for n, d in ((1, 128), (7, 4096), (16, 4096), (8191, 4096), (8192, 4096)):
            for scale in (0.0, 1e-7, 1.0, 100.0):
                x = torch.randn(n, 4, d, device="cuda", dtype=torch.bfloat16) * scale
                b = torch.randn(n, d, device="cuda", dtype=torch.bfloat16) * scale
                coeff = torch.randn(n, 24, device="cuda")
                p = coeff[:, :4].sigmoid()
                post = 2 * coeff[:, 4:8].sigmoid()
                m = coeff[:, 8:].view(n, 4, 4).softmax(-1)
                flat = x.flatten(-2).float()
                expected_norm = flat * torch.rsqrt(flat.square().mean(-1, keepdim=True) + 1e-6)
                expected_pre = (p.bfloat16().unsqueeze(-2) @ x).squeeze(-2)
                expected_merge = m.bfloat16() @ x + post.bfloat16().unsqueeze(-1) * b.unsqueeze(-2)
                for name, actual, expected in (("norm", norm(x), expected_norm), ("pre", pre(x, p), expected_pre), ("merge", merge(x, b, post, m), expected_merge), ("epilogue", merge(x, b, post, m, False), expected_merge)):
                    print(json.dumps({"n": n, "d": d, "scale": scale, **check(name, actual, expected)}), flush=True)
